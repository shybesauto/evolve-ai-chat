# Evolve AI Chat (Vercel Function)

This repo contains the serverless function for Evolve Auto Service’s AI chat.

## Setup on Vercel
1. Create a new Vercel project and import this repo.
2. In **Project Settings → Environment Variables**, add:
   - `OPENAI_API_KEY` = your OpenAI API key
3. Deploy. Your function will be live at:
   `https://<your-project>.vercel.app/api/chat`

## Usage
Point your website’s chat widget to that endpoint, e.g.:
```js
fetch('https://<your-project>.vercel.app/api/chat', { ... })
```
